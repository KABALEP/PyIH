package ic2.api.energy.tile;

public interface IMultiEnergySource extends IEnergySource {
  boolean sendMultibleEnergyPackets();
  
  int getMultibleEnergyPacketAmount();
}


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\energy\tile\IMultiEnergySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */