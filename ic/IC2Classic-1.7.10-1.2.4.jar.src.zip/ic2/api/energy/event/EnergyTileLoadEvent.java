/*    */ package ic2.api.energy.event;
/*    */ 
/*    */ import ic2.api.energy.tile.IEnergyTile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnergyTileLoadEvent
/*    */   extends EnergyTileEvent
/*    */ {
/*    */   public EnergyTileLoadEvent(IEnergyTile energyTile1) {
/* 23 */     super(energyTile1);
/*    */   }
/*    */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\energy\event\EnergyTileLoadEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */