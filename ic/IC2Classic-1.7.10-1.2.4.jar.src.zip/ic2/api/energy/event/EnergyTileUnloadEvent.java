/*    */ package ic2.api.energy.event;
/*    */ 
/*    */ import ic2.api.energy.tile.IEnergyTile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnergyTileUnloadEvent
/*    */   extends EnergyTileEvent
/*    */ {
/*    */   public EnergyTileUnloadEvent(IEnergyTile energyTile1) {
/* 24 */     super(energyTile1);
/*    */   }
/*    */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\energy\event\EnergyTileUnloadEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */