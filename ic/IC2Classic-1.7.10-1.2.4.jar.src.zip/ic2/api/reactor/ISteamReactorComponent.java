package ic2.api.reactor;

import net.minecraft.item.ItemStack;

public interface ISteamReactorComponent extends IReactorComponent {
  void processTick(ISteamReactor paramISteamReactor, ItemStack paramItemStack, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\reactor\ISteamReactorComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */