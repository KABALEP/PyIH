package ic2.api.item;

import java.util.List;
import net.minecraft.item.ItemStack;

public interface IItemHudInfo {
  List<String> getHudInfo(ItemStack paramItemStack);
}


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\item\IItemHudInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */