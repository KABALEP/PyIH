package ic2.api.network;

public interface INetworkUpdateListener {
  void onNetworkUpdate(String paramString);
}


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\api\network\INetworkUpdateListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */