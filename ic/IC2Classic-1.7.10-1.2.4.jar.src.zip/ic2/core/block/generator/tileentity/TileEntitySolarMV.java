/*    */ package ic2.core.block.generator.tileentity;
/*    */ 
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class TileEntitySolarMV
/*    */   extends TileEntitySolarGenerator
/*    */ {
/*    */   public TileEntitySolarMV() {
/*  9 */     super(1, 64, 256);
/* 10 */     this.tier = 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 16 */     return StatCollector.func_74838_a("blockSolarMV.name");
/*    */   }
/*    */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\generator\tileentity\TileEntitySolarMV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */