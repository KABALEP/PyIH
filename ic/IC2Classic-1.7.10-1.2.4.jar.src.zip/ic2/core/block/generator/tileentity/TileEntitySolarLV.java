/*    */ package ic2.core.block.generator.tileentity;
/*    */ 
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class TileEntitySolarLV
/*    */   extends TileEntitySolarGenerator
/*    */ {
/*    */   public TileEntitySolarLV() {
/*  9 */     super(1, 8, 32);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 15 */     return StatCollector.func_74838_a("blockSolarLV.name");
/*    */   }
/*    */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\generator\tileentity\TileEntitySolarLV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */