/*    */ package ic2.core.block.wiring;
/*    */ 
/*    */ public class TileEntityElectricMFE
/*    */   extends TileEntityElectricBlock
/*    */ {
/*    */   public TileEntityElectricMFE() {
/*  7 */     super(2, 128, 600000);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_145825_b() {
/* 13 */     return "MFE";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaxEnergyAmount() {
/* 19 */     return 128;
/*    */   }
/*    */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\wiring\TileEntityElectricMFE.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */