/*   */ package ic2.core.block.wiring;
/*   */ 
/*   */ public class TileEntityTransformerMV
/*   */   extends TileEntityTransformer
/*   */ {
/*   */   public TileEntityTransformerMV() {
/* 7 */     super(128, 512, 1024);
/*   */   }
/*   */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\wiring\TileEntityTransformerMV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */