/*   */ package ic2.core.block.wiring;
/*   */ 
/*   */ public class TileEntityTransformerLV
/*   */   extends TileEntityTransformer
/*   */ {
/*   */   public TileEntityTransformerLV() {
/* 7 */     super(32, 128, 256);
/*   */   }
/*   */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\wiring\TileEntityTransformerLV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */