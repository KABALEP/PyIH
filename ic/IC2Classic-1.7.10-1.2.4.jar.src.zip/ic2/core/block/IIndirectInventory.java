package ic2.core.block;

public interface IIndirectInventory {
  void openInventory();
  
  void closeInventory();
}


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\block\IIndirectInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */