/*   */ package ic2.core.audio;
/*   */ 
/*   */ public enum PositionSpec
/*   */ {
/* 5 */   Center,
/* 6 */   Backpack,
/* 7 */   Hand;
/*   */ }


/* Location:              C:\Users\KABALEP\Desktop\мусор\IC2Classic-1.7.10-1.2.4.jar!\ic2\core\audio\PositionSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */